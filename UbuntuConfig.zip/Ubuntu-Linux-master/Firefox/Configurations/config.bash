#!/bin/sh

# Ouvrir Firefox pour créer un profil
firefox www.google.be &

# Installer un background personnalisé
gsettings set org.gnome.desktop.background picture-uri "file:///home/ubuntu/Desktop/Ubuntu-Linux-master/Divers/image.jpg"

# Autorisé les téléchargements de servers divers
sudo add-apt-repository universe
sudo add-apt-repository multiverse

# Ajouter le server où se trouve flashPlayer dans la liste des servers de téléchargement de packages
sudo add-apt-repository "deb http://archive.canonical.com/ $(lsb_release -sc) partner"

# Mettre à jour le repository (liste des servers de téléchargement de packages)
sudo apt update

# Mettre d'actualité la liste des servers de téléchargement de packages
sudo apt -y upgrade

# Couper Firefox
pkill -f firefox

# Install and show Keyboard Virtual
sudo apt -y install onboard

# Installer Adobe Flash pour Firefox
sudo apt -y install adobe-flashplugin browser-plugin-freshplayer-pepperflash

# Importer dans Firefox les favoris sauvegardés
mv /home/ubuntu/Desktop/Ubuntu-Linux-master/Firefox/Favoris/bookmarks-2018-10-18_413_2yOFe0jj0pXUcc010Gp4TA\=\=.jsonlz4 /home/ubuntu/.mozilla/firefox/*.default/bookmarkbackups/

mv /home/ubuntu/Desktop/Ubuntu-Linux-master/Firefox/Favoris/prefs.js /home/ubuntu/.mozilla/firefox/*.default/

mv /home/ubuntu/Desktop/Ubuntu-Linux-master/Firefox/Favoris/xulstore.json /home/ubuntu/.mozilla/firefox/*.default/

# Ouvrir Firefox et installer AdBlock
firefox https://addons.mozilla.org/firefox/downloads/file/1061111/adblock_plus-3.3.1-an+fx.xpi www.hds.to www.youtube.com/watch?v=f6vY6tYvKGA&index=2&list=PLUUd021YsPvUORhImb1WVfWll0wlNG-iW &

# Ouvrir le clavier virtuel
onboard &

# Mettre le clavier en francais (belge).
setxkbmap be


