#!/bin/bash

timer=$1

while [ $timer -gt 0 ]
do
	echo "L'ordinateur va se mettre en veille dans: $timer secondes"
	sleep 1
	timer=$(($timer - 1))
	clear
done

systemctl suspend
